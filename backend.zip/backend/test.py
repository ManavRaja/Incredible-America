    geo_api_res = make_request_to_geo_api(request.client.host) # Makes request to geolocation API and returns the response
    client_state = get_client_state_and_set_cookie(request, response, geo_api_res) # Takes in response from geolocation API and sets cookie with client's state and returns the client's state
    client_state = "Random state"

    